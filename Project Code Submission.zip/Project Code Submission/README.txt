This file is intended to provide basic details on the include code, 
to make it easier to open or build, as required. 

---Chat Client---
This is a Visual Studio solution, developed in Visual Studio 2022

---Chat Server--- 
This is a Python file, developed using python 3.10.x

---Endpoint--- 
This is an Arduino Sketch file, for use with Arduino IDE

---Gateway---
This is an Arduino Sketch file, for use with Arduino IDE